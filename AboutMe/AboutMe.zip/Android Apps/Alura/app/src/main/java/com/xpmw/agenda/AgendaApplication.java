package com.xpmw.agenda;

import android.app.Application;

import com.xpmw.agenda.DAO.AlunoDAO;
import com.xpmw.agenda.model.Aluno;

public class AgendaApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        criaAlunosDeTeste();

    }

    private void criaAlunosDeTeste() {
        //Referencia de Aluno Dao
        AlunoDAO dao = new AlunoDAO();

        //Dando entrada em alunos manualmente
        dao.salva(new Aluno("Eryck Kaique", "88766", "eryck@.com"));
        dao.salva(new Aluno("Kaqiue Nascimento", "88766", "kaique@.com"));
        dao.salva(new Aluno("Bruna limeiro", "88766", "bruna@.com"));
    }
}

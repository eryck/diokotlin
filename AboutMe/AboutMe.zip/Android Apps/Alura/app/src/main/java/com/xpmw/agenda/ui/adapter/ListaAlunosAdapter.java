package com.xpmw.agenda.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.xpmw.agenda.R;
import com.xpmw.agenda.model.Aluno;

import java.util.ArrayList;
import java.util.List;

public class ListaAlunosAdapter extends BaseAdapter {
    //Recupera a quantidade de alunos
    private final List<Aluno> alunos = new ArrayList<>();
    private final Context context;

    public ListaAlunosAdapter(Context context) {
        this.context = context;
    }

    //Indica a quantidade de elementos que o adapter terá
    //representa a quantidade de elementos do adapter
    @Override
    public int getCount() {
        return alunos.size();
    }

    //Inidica o item que será pego pela posição
    //Retorna o elemento pela posição
    @Override
    public Aluno getItem(int position) {
        return alunos.get(position);
    }

    //Representa o ID da posiçao
    //retornar o id do elemento pela posição
    @Override
    public long getItemId(int position) {
        return alunos.get(position).getId();
    }

    //Gera a View com base no leyput, inflando o layout
    //cria a view para cada elemento
    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {

        View viewCriada = criaView(viewGroup);
        //Recupera o Aluno para o inflate
        Aluno alunoDevolvido = alunos.get(position);
        vincula(viewCriada, alunoDevolvido);

        return viewCriada;
    }

    private void vincula(View view, Aluno aluno) {
        //Referencia os textView do layout de Alunos
        TextView nomeAluno = view.findViewById(R.id.item_aluno_nome);
        TextView telefoneAluno = view.findViewById(R.id.item_aluno_telefone);
        TextView emailAluno = view.findViewById(R.id.item_aluno_email);
        //Passa os dados para preenchimento
        nomeAluno.setText(aluno.getNome());
        telefoneAluno.setText(aluno.getTelefone());
        emailAluno.setText(aluno.getEmail());
    }

    private View criaView(ViewGroup viewGroup) {
        return LayoutInflater.from(context).inflate(R.layout.item_aluno, viewGroup, false);
    }

    public void atualiza(List<Aluno> alunos){
        this.alunos.clear();
        this.alunos.addAll(alunos);
        notifyDataSetChanged();
    }

    public void remove(Aluno aluno) {
        alunos.remove(aluno);
        notifyDataSetChanged();
    }
}

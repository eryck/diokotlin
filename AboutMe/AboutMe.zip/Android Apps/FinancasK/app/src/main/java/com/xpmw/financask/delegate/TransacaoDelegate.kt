package com.xpmw.financask.delegate

import com.xpmw.financask.model.Transacao

interface TransacaoDelegate {

    fun delegate(transacao: Transacao)
}
package com.xpmw.financask.extension

import java.text.SimpleDateFormat
import java.util.Calendar

fun Calendar.formataParaBrasileiro() : String{
    //Formatando e imprimindo a data
    val formatoBrasileiro = "dd/MM/yyy"
    val format = SimpleDateFormat(formatoBrasileiro)
    return format.format(this.time)
}
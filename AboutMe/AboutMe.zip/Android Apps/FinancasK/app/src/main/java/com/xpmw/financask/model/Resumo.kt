package com.xpmw.financask.model

import java.math.BigDecimal

class Resumo(private val transacoes: List<Transacao>) {

    //Modo 1
    /*
    fun receita(): BigDecimal{
        /*
        var totalReceita = BigDecimal.ZERO
        for (transacao in transacoes) {
            if (transacao.tipo == Tipo.RECEITA) {
                totalReceita = totalReceita.plus(transacao.valor)
            }
        }
        return totalReceita
         */
        return somaPor(Tipo.RECEITA)
    }
     */

    //Modo 2
    /*
    fun receita() = somaPor(Tipo.RECEITA)
    fun despesa() = somaPor(Tipo.DESPESA)
    fun total() = receita().subtract(despesa())
    */

    //Modo com Property
    val receita get() = somaPor(Tipo.RECEITA)
    val despesa get() = somaPor(Tipo.DESPESA)
    val total get() = receita.subtract(despesa)

    private fun somaPor(tipo: Tipo): BigDecimal{
        val somaDeTransacoesPeloTipo = transacoes.filter { it.tipo == tipo }
                .sumByDouble { it.valor.toDouble() }
        return BigDecimal(somaDeTransacoesPeloTipo)
    }

}
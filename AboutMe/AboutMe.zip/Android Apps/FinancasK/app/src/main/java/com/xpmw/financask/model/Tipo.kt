package com.xpmw.financask.model

enum class Tipo {
    RECEITA, DESPESA
}
package com.xpmw.financask.ui.activity

import android.os.Bundle
import android.view.ViewGroup
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.github.clans.fab.FloatingActionButton
import com.github.clans.fab.FloatingActionMenu
import com.xpmw.financask.R
import com.xpmw.financask.delegate.TransacaoDelegate
import com.xpmw.financask.model.Tipo
import com.xpmw.financask.model.Transacao
import com.xpmw.financask.ui.ResumoView
import com.xpmw.financask.ui.dialog.AdicionaTransacaoDialog
import com.xpmw.financask.ui.dialog.AlteraTransacaoDialog

class ListaTransacoesActivity : AppCompatActivity() {

    private val transacoes: MutableList<Transacao> = mutableListOf()
    private  val viewDaActivity = window.decorView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_transacoes)

        configuraResumo()
        configuraLista()
        configuraFab()
    }

    private fun configuraFab() {
        findViewById<FloatingActionButton>(R.id.lista_transacoes_adiciona_receita)
                .setOnClickListener {
                    chamaDialogDeAdicao(Tipo.RECEITA)
                }

        findViewById<FloatingActionButton>(R.id.lista_transacoes_adiciona_despesa)
                .setOnClickListener {
                    chamaDialogDeAdicao(Tipo.DESPESA)
                }
    }

    private fun chamaDialogDeAdicao(tipo: Tipo) {
        AdicionaTransacaoDialog(viewDaActivity as ViewGroup, this)
                .chama(tipo, object : TransacaoDelegate {
                    override fun delegate(transacao: Transacao) {
                        adiciona(transacao)
                        findViewById<FloatingActionMenu>(R.id.lista_transacoes_adiciona_menu).close(true)
                    }
                })
    }

    private fun adiciona(transacao: Transacao) {
        transacoes.add(transacao)
        atualizaTranzacoes()
    }

    private fun atualizaTranzacoes() {
        configuraLista()
        configuraResumo()
    }

    private fun configuraResumo() {
        val view = viewDaActivity
        val resumoView = ResumoView(this, view, transacoes)
        resumoView.atualiza()
    }

    private fun configuraLista() {
        val ListaTransacaoesAdapter = ListaTransacaoesAdapter(transacoes, this)
        with(findViewById<ListView>(R.id.lista_transacoes_listview)){
            adapter = ListaTransacaoesAdapter
            setOnItemClickListener { _, _, position, _ ->
                val transacao = transacoes[position]
                chamaDialogDeAlteracao(transacao, position)
            }
        }
    }

    private fun chamaDialogDeAlteracao(transacao: Transacao, position: Int) {
        AlteraTransacaoDialog(viewDaActivity as ViewGroup, this)
                .chama(transacao, object : TransacaoDelegate {
                    override fun delegate(transacao: Transacao) {
                        altera(transacao, position)
                    }

                })
    }

    private fun altera(transacao: Transacao, position: Int) {
        transacoes[position] = transacao
        atualizaTranzacoes()
    }


}
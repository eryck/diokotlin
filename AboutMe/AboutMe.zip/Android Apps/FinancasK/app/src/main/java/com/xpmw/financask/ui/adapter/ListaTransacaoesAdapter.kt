package com.xpmw.financask.ui.activity

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.xpmw.financask.R
import com.xpmw.financask.extension.formataParaBrasileiro
import com.xpmw.financask.extension.limitaEmAte
import com.xpmw.financask.model.Tipo
import com.xpmw.financask.model.Transacao

class ListaTransacaoesAdapter(
        private val transacoes: List<Transacao>,
        private val context: Context) : BaseAdapter() {

    override fun getCount(): Int {
        return transacoes.size
    }

    override fun getItem(position: Int): Transacao {
        return transacoes[position]
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    private val LIMITE_DE_CATEGORIA = 14

    override fun getView(position: Int, view: View?, parent: ViewGroup?): View {
        val viewCriada = LayoutInflater.from(context).inflate(R.layout.transacao_item, parent, false)

        val transacao = transacoes[position]

        formataView(transacao, viewCriada)
        adicionaValor(viewCriada, transacao)
        adicionaCategoria(viewCriada, transacao)
        adicionaData(viewCriada, transacao)
        return viewCriada
    }

    private fun adicionaData(viewCriada: View, transacao: Transacao) {
        viewCriada.findViewById<TextView>(R.id.transacao_data).text = transacao.data.formataParaBrasileiro()
    }

    private fun adicionaCategoria(viewCriada: View, transacao: Transacao) {
        viewCriada.findViewById<TextView>(R.id.transacao_categoria).text = transacao.categoria.limitaEmAte(LIMITE_DE_CATEGORIA)
    }

    private fun adicionaValor(viewCriada: View, transacao: Transacao) {
        viewCriada.findViewById<TextView>(R.id.transacao_valor).text = transacao.valor.formataParaBrasileiro()
    }

    private fun formataView(transacao: Transacao, viewCriada: View) {

        val cor = corPor(transacao.tipo)
        viewCriada.findViewById<TextView>(R.id.transacao_valor).setTextColor(cor)

        val icone = iconePor(transacao.tipo)
        viewCriada.findViewById<ImageView>(R.id.transacao_icone).setBackgroundResource(icone)
    }

    private fun iconePor(tipo: Tipo): Int {
        if (tipo == Tipo.RECEITA) {
            return R.drawable.icone_transacao_item_receita
        }
        return  R.drawable.icone_transacao_item_despesa
    }

    private fun corPor(tipo: Tipo): Int {
        if (tipo == Tipo.RECEITA) {
            return  ContextCompat.getColor(context, R.color.receita)
        }
         return ContextCompat.getColor(context, R.color.despesa)
    }
}